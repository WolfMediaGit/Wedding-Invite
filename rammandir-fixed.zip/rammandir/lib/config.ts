/**
 * Everything a couple would change lives here. Visual layout (positions, sizes,
 * fonts) lives in data/*.json, measured from the Framer site.
 */

export const wedding = {
  bride: "Drashti",
  groom: "Akash",
  /** Countdown target. The Framer site's event card reads "29th Aug 2026, 6 Pm Onwards". */
  date: "2026-08-29T18:00:00+05:30",
  hashtag: "#abkan",
  /** RSVP WhatsApp number in international format, digits only (taken from the live form). */
  whatsappNumber: "919819200906",
  meta: {
    title: "Ram Mandir | A Divine Wedding Theme",
    description: "A beautifully crafted wedding invitation inspired by the divine beauty of Ram Mandir. 🪷✨",
    ogImage: "https://framerusercontent.com/images/3JekLBRwVWegsCm3gX3wOcYeM.webp",
  },
};

/** Timeline cards, in the order they sit on the page (1–6). */
export const events = Array.from({ length: 6 }, () => ({
  title: "Shaadi",
  day: "Friday",
  date: "29th Aug 2026",
  place: "Pune, Maharashtra",
  time: "6 Pm Onwards",
  note: "More details below",
}));

/** Options in the RSVP "Select Event" dropdown (multi-select). */
export const rsvpEvents = ["Mehendi", "Sangeet", "Wedding Ceremony", "Reception"];
export const maxGuests = 50;

/** Builds the exact message the Framer form sends. */
export function rsvpMessage(name: string, selected: string[], people: string) {
  return `Hi! I'd like to RSVP.\nName: ${name}\nEvent(s): ${selected.join(", ")}\nNumber of People: ${people}`;
}

export type Venue = {
  label: string;
  name: string;
  /** The live site shows a different address string on its mobile and desktop layouts. */
  address: { mobile: string; desktop: string };
  lat: number;
  lng: number;
};

/** Location switcher under the map. Only the first location's coordinates exist on the live site. */
export const venues: Venue[] = [
  {
    label: "Location 1",
    name: "Venue Name",
    address: {
      mobile: "M10 geomatrix silver crest kamote 9819200906 M10 geomatrix silver crest kamote 9819200906",
      desktop: "Full street address, city, state, ZIP",
    },
    lat: 19.2183,
    lng: 72.9781,
  },
  { label: "Location 2", name: "Venue Name", address: { mobile: "Full street address, city, state, ZIP", desktop: "Full street address, city, state, ZIP" }, lat: 19.2183, lng: 72.9781 },
  { label: "Location", name: "Venue Name", address: { mobile: "Full street address, city, state, ZIP", desktop: "Full street address, city, state, ZIP" }, lat: 19.2183, lng: 72.9781 },
  { label: "Location", name: "Venue Name", address: { mobile: "Full street address, city, state, ZIP", desktop: "Full street address, city, state, ZIP" }, lat: 19.2183, lng: 72.9781 },
];

export const message =
  "Our hearts are full and our smiles wide, we can hardly believe our dreamy eyed teen selves made it here! " +
  "We’re ready to make memories that last a lifetime, and they’ll be incomplete without you by your side. " +
  "Come celebrate our love, share our joy, eat. till you can’t move and help us make this day a beautiful, laughter-filled blur we’ll never forget!";

/** "Almost time to celebrate" wheel. These are the placeholder photos the Framer site itself uses. */
export const galleryPhotos = [
  "https://images.unsplash.com/photo-1506744038136-46273834b3fb",
  "https://images.unsplash.com/photo-1469474968028-56623f02e42e",
  "https://images.unsplash.com/photo-1447752875215-b2761acb3c5d",
  "https://images.unsplash.com/photo-1433086966358-54859d0ed716",
  "https://images.unsplash.com/photo-1470071459604-3b5ec3a7fe05",
];

export const thingsToKnow = [
  { key: "hashtag", title: "Hashtag", icon: "EUPxZZrFKaWt9CBkczGVfDOj1c.webp", lines: ["While posting photos", "on social media please use", `the hashtag - ${wedding.hashtag}`] },
  { key: "weather", title: "Weather", icon: "KrRp2Koc5I3NO7nOduBFAoCVlQ.webp", lines: ["It will be mostly sunny with temperature reaching up to 28 degrees at the venue"] },
  { key: "staff", title: "Staff", icon: "hjcRmZcFhVMnmuu2IHPnk7pOudQ.webp", lines: ["We recommend the nearby hotel called Bhola Bhawan near the venue for the staff members"] },
  { key: "parking", title: "Parking", icon: "5uWzJVw11PDVfozRAkpivVBUPw.webp", lines: ["Valet parking for all our guests will be available at the venue"] },
];
